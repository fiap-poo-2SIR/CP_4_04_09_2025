import java.sql.*;

public class JavaCorrida {
    public static void main (String[] args) {
        String url = "jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL";
        String user = "rm556722";
        String password = "100606";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement()){

            //1 Inserir Registros
            String insert1 = "INSERT INTO java_corrida (id, motorista, distancia, consumo, preco)VALUES (1, 'Carlos', 10, 11, 20)";
            String insert2 = "INSERT INTO java_corrida (id, motorista, distancia, consumo, preco)VALUES (2, 'Joao', 30, 33, 60)";
            String insert3 = "INSERT INTO java_corrida (id, motorista, distancia, consumo, preco)VALUES (3, 'Marcos', 60, 66, 120)";
            stmt.execute(insert1);
            stmt.execute(insert2);
            stmt.execute(insert3);

            //2) Listar todos os dados
            System.out.println("===Tabela de Corrida===");
            ResultSet rs = stmt.executeQuery("SELECT*FROM java_corrida");
            while (rs.next()){
                System.out.println(
                        "ID: " + rs.getInt("id")+
                                ",Vendedor: " + rs.getString("motorista")+
                                ",Distancia" + rs.getDouble("distancia")+
                                ",Consumo" + rs.getDouble("consumo")+
                                ",Preco" + rs.getDouble("preco")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
