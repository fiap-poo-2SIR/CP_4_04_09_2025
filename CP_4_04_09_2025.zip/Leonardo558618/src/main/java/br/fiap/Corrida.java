package br.fiap;

public class Corrida {
    private int id;
    private String motorista;
    private double distancia;
    private double consumo;
    private double preco;

    public Corrida(int id, String motorista, double distancia, double consumo, double preco) {
        this.id = id;
        this.motorista = motorista;
        this.distancia = distancia;
        this.consumo = consumo;
        this.preco = preco;
    }

    public int getId() {
        return id;
    }

    public String getMotorista() {
        return motorista;
    }

    public double getDistancia() {
        return distancia;
    }

    public double getConsumo() {
        return consumo;
    }

    public double getPreco() {
        return preco;
    }

    @Override
    public String toString() {
        return "Corrida{" +
                "id=" + id +
                ", motorista='" + motorista + '\'' +
                ", distancia=" + distancia +
                ", consumo=" + consumo +
                ", preco=" + preco +
                '}';
    }
}
