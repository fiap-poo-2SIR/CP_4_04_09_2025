package br.fiap;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Corrida corrida1 = new Corrida(1, "Bruce Wayne", 52.3, 10.2, 101.2);
        Corrida corrida2 = new Corrida(2, "Clark Kent", 153.4, 200.2, 151.2);
        Corrida corrida3 = new Corrida(3, "Tony Stark", 100, 30.8, 300.5);

        CorridaDAO corridaDAO = new CorridaDAO();

        corridaDAO.inserir(corrida1);
        corridaDAO.inserir(corrida2);
        corridaDAO.inserir(corrida3);

        List<Corrida> lista = corridaDAO.listar();

        lista.forEach(System.out::println);

        System.out.println("");

        lista.forEach(corrida -> System.out.println("Motorista: " + corrida.getMotorista() + " | Custo: " + corrida.getDistancia()/corrida.getConsumo()));

        System.out.println("");

        getGastoTotal("Bruce Wayne", lista);
    }

    public static void getGastoTotal(String name, List<Corrida> lista) {
        double total = 0;
        for(Corrida corrida : lista) {
            if (name.equals(corrida.getMotorista())){
                total += corrida.getDistancia()/corrida.getConsumo();
            }
        }

        System.out.println("Total do motorista " + name + ": " + total);
    }
}
