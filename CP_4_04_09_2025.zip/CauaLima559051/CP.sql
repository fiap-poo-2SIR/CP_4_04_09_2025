CREATE TABLE java_caloria (

    id NUMBER PRIMARY KEY,
    aluno VARCHAR2(50),
    atividade VARCHAR2(50),
    duracao NUMBER(10,2),
    caloria NUMBER(10,2)
    
)