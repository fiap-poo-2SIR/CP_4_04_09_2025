package br.fiap.model;

public class Venda {
}
