package br.fiap.model;

public class Caloria {
    private int id;
    private String aluno;
    private String atividade;
    private double duracao;
    private double caloria;

    public Caloria(int id, String aluno, String atividade, double duracao, double caloria){
        this.id = id;
        this.aluno = aluno;
        this.atividade = atividade;
        this.duracao = duracao;
        this.caloria = caloria;
    }
    public int getId() { return id;}
    public String getAluno() { return aluno; }
    public String getAtividade(){return atividade;}
    public Double getDuracao(){return duracao;}
    public Double getCaloria(){return caloria;}

    public double gastoTotal(){
        return duracao * caloria;
    }
}
