package br.fiap.model;

public class Main {
    public static void main(String[] args){

        CaloriaDAO dao = new CaloriaDAO();

        Caloria c1 = new Caloria(1, "João", "Corrida", 30, 10);
        Caloria c2 = new Caloria(2, "Maria", "Natação", 45, 8);
        Caloria c3 = new Caloria(3, "João", "Bicicleta", 60, 7);

        dao.inserir(c1);
        dao.inserir(c2);
        dao.inserir(c3);

        System.out.println("\n--- Lista de Registros ---");
        dao.listar().forEach(c ->
                System.out.println(c.getId() + "|" + c.getAluno() + "|" + c.getAtividade() + "|" + c.getDuracao() +"min |" +c.getCaloria() + "cal/min"));
        System.out.println("")

    }
}
