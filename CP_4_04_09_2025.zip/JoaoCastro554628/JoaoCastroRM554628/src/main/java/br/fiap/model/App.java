package br.fiap.model;

/**
 * Hello world!
 *
 */
public class pp
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
