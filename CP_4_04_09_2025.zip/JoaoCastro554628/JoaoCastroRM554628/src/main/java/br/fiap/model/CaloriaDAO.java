package br.fiap.model;

import jdk.internal.org.jline.terminal.TerminalBuilder;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CaloriaDAO {
    public void inserir(Caloria c){
        String sql = "INSERT INTO java_caloria (id, aluno, atividade, duracao, caloria) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)){
            ps.setInt(1, c.getId());
            ps.setString(2, c.getAluno());
            ps.setString(3, c.getAtividade());
            ps.setDouble(4,c.getDuracao());
            ps.setDouble(5,c.getCaloria());
            ps.executeUpdate();
            System.out.println("Registro inserido com sucesso");
      } catch (SQLException e){
            System.out.println("Erro ao inserir" + e.getMessage());
        }
    }

    public List<Caloria> lister(){
    List<Caloria> lista = new ArrayList<>();
    String sql= "SELECT * FROM java_caloria";
    try (Connection con = Conexao.conectar();
         Statement st = con.createStatement();
         ResultSet rs = st.executeQuery(sql)) {
        while (rs.next()){
            Caloria c = new Caloria(
                    rs.getInt("id"),
                    rs.getString("aluno"),
                    rs.getString("atividade"),
                    rs.getDouble("duracao"),
                    rs.getDouble("caloria")
            );
            lista.add(c);
        }
    } catch (SQLException e){
        System.out.println("Erro ao lista" + e.getMessage());
    }
    return lista;
    }
    public void gastoTotalAtividade(){
        String sql = "SELECT aluno, (duracao * caloria) AS gasto FROM java_caloria";
        try (Connection con = Conexao.conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()){
              System.out.println("Aluno: " + rs.getString("aluno") + "| Gasto calórico da atividade: " + rs.getDouble("gasto"));
        }
    } catch (SQLException e){
            System.out.println("Erro: " e.getMessage());
        }
}
    public void gastoTotalPorAluno(String nomeAluno) {
    String sql = "SELECT aluno, SUM(duracao * caloria) AS total FROM java_caloria WHERE aluno = ? GROUP BY aluno"};
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
             ps.setStrin(1, nomeAluno);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                System.out.println("Aluno: " + rs.getString("aluno") + "| Gasto calórico total : " + rs.getDouble("total"));
            } else {
                System.out.println("Aluno nao encontrado");
            } catch (SQLException e){
            System.out.println("Erro: " + e.getMessage());
        }

    }
}