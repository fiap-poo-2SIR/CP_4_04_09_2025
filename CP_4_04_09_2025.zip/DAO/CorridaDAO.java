package DAO;

import Models.Conexao;
import Models.Corrida;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CorridaDAO {

    PreparedStatement ps;

    String sql;

    ResultSet rs;

    public void insert(Corrida corrida) {
        sql = "INSERT INTO  java_corrida VALUES (?, ?, ?, ?, ?)";
        try (Connection conexao = Conexao.conectar()) {
            ps = conexao.prepareStatement(sql);
            ps.setInt(1, corrida.getId());
            ps.setString(2, corrida.getMotorista());
            ps.setDouble(3, corrida.getDistancia());
            ps.setDouble(4, corrida.getConsumo());
            ps.setDouble(5, corrida.getPreco());
            ps.execute();
        }catch (SQLException e){
            System.out.println("Erro ao inserir  dados na tabela java_corrida");
        }
    }

    public List<Corrida> select()  {
            List<Corrida> corridas = new ArrayList<>();
        sql = "Select * from java_corrida";
        try(Connection conexao =  Conexao.conectar()){
                ps = conexao.prepareStatement(sql);
                rs = ps.executeQuery();
                Integer id;
                String motorista;
                double distancia;
                double consumo;
                double preco;
                while (rs.next()){
                     id = rs.getInt("id");
                     motorista = rs.getString("motorista");
                     distancia = rs.getDouble("distancia");
                     consumo = rs.getDouble("consumo");
                     preco = rs.getDouble("preco");

                     corridas.add(new Corrida(id, motorista, distancia, consumo, preco));
                }

            }catch (SQLException e){
                System.out.println("Erro ao buscar os dados da tabela java_corrida");
            }

        return corridas;
    }

    public Corrida selectMotorista(String motoristaSelec) {
        sql = "Select * from java_corrida where (?)";
        try (Connection conexao = Conexao.conectar()) {
            ps = conexao.prepareStatement(sql);
            ps.setString(1, motoristaSelec);
            rs = ps.executeQuery();
            Integer id;
            String motorista;
            double distancia;
            double consumo;
            double preco;
            int i = 0;
            Corrida corrida = new Corrida();
            while (rs.next()){
                if (i == 0){

                }
                    id = rs.getInt("id");
                    motorista = rs.getString("motorista");
                    distancia = rs.getDouble("distancia");
                    consumo = rs.getDouble("consumo");
                    preco = rs.getDouble("preco");
                 //   Corrida corrida = new Corrida(id, motorista, distancia, consumo, preco);
            }


            return corrida;
        } catch (SQLException e) {
            System.out.println("Erro ao buscar os dados da tabela java_corrida");
        }


        return null;
    }

}
