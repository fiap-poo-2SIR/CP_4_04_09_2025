package CP04;

import java.util.List;

public class Main {
    public static void main(String[] args) {

        UserDAO userDAO = new UserDAO();

        User user1 = new User(1, "Gustavo", "Futebol", 20.0, 100.0);
        User user2 = new User(2, "Gabriel", "Basquete", 10.0, 100.0);
        User user3 = new User(3, "Rafael", "Volei", 30.0, 100.0);

        //userDAO.inserir(user1);
        //userDAO.inserir(user2);
        //userDAO.inserir(user3);

        List<User> listaUsuarios = userDAO.listar();
        System.out.println("--- USUARIOS ---");
        for (User user : listaUsuarios) {
            System.out.println(user);
        }

        List<User> listaGastos = userDAO.gastos();
        System.out.println("--- GASTOS DE CALORIAS ---");
        for (User user : listaGastos) {
            System.out.println(user);
        }
    }
}
