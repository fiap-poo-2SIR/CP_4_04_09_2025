package CP04;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
    private PreparedStatement ps;
    private ResultSet rs;
    private String sql;

    public List<User> listar() {
        List<User> lista = new ArrayList<>();
        sql = "select * from java_caloria";

        try(Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new User(rs.getInt("id"), rs.getString("aluno"), rs.getString("atividade"), rs.getDouble("duracao"), rs.getDouble("caloria")));
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar os Alunos!");
        }
        return lista;
    }

    public List<User> gastos() {
        List<User> gastos = new ArrayList<>();
        sql = "select duracao, caloria from java_caloria";

        try(Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                gastos.add(new User(rs.getInt("id"), rs.getString("aluno"), rs.getString("atividade"), rs.getDouble("duracao"), rs.getDouble("caloria")));
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar os Alunos!");
        }
        return gastos;
    }

    public void inserir(User user) {
        sql = "insert into java_caloria values (?,?,?,?,?)";

        try(Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            ps.setInt(1, user.getId());
            ps.setString(2, user.getAluno());
            ps.setString(3, user.getAtividade());
            ps.setDouble(4, user.getDuracao());
            ps.setDouble(5, user.getCaloria());
            ps.execute();
        } catch (SQLException e) {
            System.out.println("Erro ao inserir Aluno no banco de dados!");
        }

    }
}
