package CP04;

import oracle.sql.NUMBER;

public class User {
    private int id;
    private String aluno;
    private String atividade;
    private Double duracao;
    private Double caloria;
    private Double gasto;

    public User(int id, String aluno, String atividade, Double duracao, Double caloria) {
        this.id = id;
        this.aluno = aluno;
        this.atividade = atividade;
        this.duracao = duracao;
        this.caloria = caloria;
        this.gasto = gasto;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAluno() {
        return aluno;
    }

    public void setAluno(String aluno) {
        this.aluno = aluno;
    }

    public String getAtividade() {
        return atividade;
    }

    public void setAtividade(String atividade) {
        this.atividade = atividade;
    }

    public Double getDuracao() {
        return duracao;
    }

    public void setDuracao(Double duracao) {
        this.duracao = duracao;
    }

    public Double getCaloria() {
        return caloria;
    }

    public void setCaloria(Double caloria) {
        this.caloria = caloria;
    }

    public Double getGasto() {
        return gasto;
    }

    public void setGasto(Double gasto) {
        this.gasto = gasto;
    }

    @Override
    public String toString() {
        return "ID: " + id + "\t Aluno: " + aluno + "\t Atividade: " + atividade + "\t Duracao: " + duracao + "\t Calorias: " + caloria;
    }
}
