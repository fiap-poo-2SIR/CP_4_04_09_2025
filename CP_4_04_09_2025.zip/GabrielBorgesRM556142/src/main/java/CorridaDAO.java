import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CorridaDAO {
    public void inserir(Corrida corrida) {
        String sql = "INSERT INTO java_corrida(id,motorista,distancia,consumo,preco)VALUES(?,?,?,?,?)";
        try (Connection connection = Conexao.conectar();
             PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, corrida.getId());
            pstmt.setString(2, corrida.getMotorista());
            pstmt.setDouble(3, corrida.getDistância());
            pstmt.setDouble(4, corrida.getConsumo());
            pstmt.setDouble(5, corrida.getPreco());
            pstmt.executeUpdate();
            System.out.println(corrida.getMotorista() + "Inserido com Sucesso");
        } catch (SQLException e) {
            System.out.println("Erro ao inserir" + e.getMessage());
        }
    }
    public List<Corrida>listarTodos() {
        List<Corrida> corridas = new ArrayList<>();
        String sql = ("SELECT ID,motorista,distancia,consumo,preco FROM java_corrida ORDER BY id");
        try (Connection connection = Conexao.conectar();
        Statement stmt = connection.createStatement();
        ResultSet rs = stmt.executeQuery(sql)) {
    while (rs.next()) {
        corridas.add(new Corrida(rs.getInt("id"), rs.getString("motorista"), rs.getDouble("distancia"), rs.getDouble("consumo"), rs.getDouble("preco")));
    }
        } catch (SQLException e) {
            System.out.println("Erro ao listar corridas:" + e.getMessage());
        }
return corridas;
    }

}
