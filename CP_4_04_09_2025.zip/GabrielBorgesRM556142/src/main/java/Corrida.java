public class Corrida {
    private int id;
    private String motorista;
    private double distância;
    private double consumo;
    private double preco;

    public Corrida(int i, String joão, Object o) {
    }

    public Corrida(int id, String motorista, double distancia, double consumo, double preco) {
    }

    public double getConsumo() {
        return consumo;
    }

    public void setConsumo(double consumo) {
        this.consumo = consumo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMotorista() {
        return motorista;
    }

    public void setMotorista(String motorista) {
        this.motorista = motorista;
    }

    public double getDistância() {
        return distância;
    }

    public void setDistância(double distância) {
        this.distância = distância;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }


}
