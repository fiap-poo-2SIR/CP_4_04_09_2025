public class Main {
    public static void main(String[] args) {
        CorridaDAO corridaDAO = new CorridaDAO();
        System.out.println("Iniciando Processo");

        System.out.println("Inserindo Corridas");

    }
}
//Professor, eu tava conseguindo mas fiquei meia hora resolvendo problema de parênteses e chaves :(, não consegui finalizar mas tava no caminho bom eu tentei