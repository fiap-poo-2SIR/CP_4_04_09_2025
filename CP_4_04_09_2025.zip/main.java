import DAO.CorridaDAO;
import Models.Corrida;

import java.util.ArrayList;
import java.util.List;

public class main {

    public static void main(String[] args) {
        // chumbado id 1 para insert
        Corrida corrida1 = new Corrida(1,"Selmini", 100, 1.5, 30);
        CorridaDAO corridaDAO = new CorridaDAO();
       corridaDAO.insert(corrida1);
        List<Corrida> corridas = new ArrayList<>();
         corridas = corridaDAO.select();
        System.out.println("Todos dados Armezanados na tabela");
         corridas.forEach( corrida -> {
             System.out.println("motrista de id: " + corrida.getId());
             System.out.print(" -Nome do  motorista: " + corrida.getMotorista());
             System.out.print(" - distância: " + corrida.getDistancia());
             System.out.print(" - consumo: " + corrida.getConsumo());
             System.out.println(" - preço: " + corrida.getPreco());
             System.out.println("----------");
         } );

        System.out.println(" Custo corrida por motorista ");
        corridas.forEach( corrida -> {
            System.out.println("Motorista: " + corrida.getMotorista());
            System.out.println("custo: " + (corrida.getDistancia()/corrida.getConsumo())*corrida.getPreco());
        });

        System.out.println("Gasto total do motorista Selmini");
        corridaDAO.selectMotorista("Selmini");

    }
}
