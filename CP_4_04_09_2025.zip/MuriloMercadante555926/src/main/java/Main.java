import java.util.List;

public class Main {
    public static void main(String[] args) {
        CorriDao dao = new CorriDao();
        Corrida corrida = new Corrida();

        corrida.setId(10);
        corrida.setMotorista("claudio");
        corrida.setDistancia(200.00);
        corrida.setConsumo(50.00);
        corrida.setPreco(40.00);
        dao.inserir(corrida);

        corrida.setId(11);
        corrida.setMotorista("patricia");
        corrida.setDistancia(300.00);
        corrida.setConsumo(60.00);
        corrida.setPreco(50.00);
        dao.inserir(corrida);


        List<Corrida> lista = dao.listar();
        double total = 0;
        for (Corrida c : lista){
            total=0;
           double d = c.getDistancia();
            double co = c.getConsumo() ;
            double p = c.getPreco();

            total =  d/co*p;
            System.out.println(c.getMotorista()+" Custo: R$ " + total);
        }







    }
}
