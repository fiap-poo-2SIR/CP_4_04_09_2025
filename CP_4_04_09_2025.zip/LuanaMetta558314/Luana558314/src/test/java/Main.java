import java.util.List;

public class Main {
    public static void main(String[] args) {
        CorridaDAO dao = new CorridaDAO();
        Corrida corrida = new Corrida(1, "Antonio", 100, 150, 200);
        dao.inserir(corrida);
        List<Corrida>lista = dao.listar();
        for(Corrida c : lista){
            System.out.println(c.getId()+" --> "+c.getMotorista()+" --> "
                    + c.getDistancia() + " --> "+ c.getConsumo() + " --> R$" +c.getPreco());
            System.out.println("------");
        }
    }
}
