import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CorridaDAO {
    private PreparedStatement ps;
    private ResultSet rs;
    private String sql;

    public void inserir (Corrida corrida){
        sql = "insert into java_corrida values (?,?,?,?,?)";
        try (Connection connection = Conexao.conectar()){
            ps= connection.prepareStatement(sql);
            ps.setInt(1, corrida.getId());
            ps.setString(2, corrida.getMotorista());
            ps.setDouble(3, corrida.getDistancia());
            ps.setDouble(4, corrida.getConsumo());
            ps.setDouble(5, corrida.getPreco());
            ps.execute();
        }
        catch (SQLException e){
            System.out.println("erro ao inserir no banco de dados\n"+e);
        }
    }
    public List<Corrida> listar(){
        List<Corrida> lista = new ArrayList<>();
        sql = "select * from java_corrida";
        try (Connection connection = Conexao.conectar()){
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                lista.add(new Corrida(rs.getInt("id"),rs.getString("motorista"),
                        rs.getDouble("distancia"), rs.getDouble("consumo"),
                        rs.getDouble("preco")));
            }
        }
        catch (SQLException e){
            System.out.println("erro ao listar categorias\n"+e);
        }
        return lista;
    }
}
