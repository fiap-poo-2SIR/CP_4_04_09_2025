package calorias;

import conexao.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AlunoDAO {

    private PreparedStatement ps;
    private ResultSet rs;
    private String sql;

    public void inserir(Aluno aluno) {
        sql = "INSERT INTO java_caloria VALUES (seqc1.nextval, ?, ?, ?, ?)";

        try(Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            ps.setString(1, aluno.getAluno());
            ps.setString(2, aluno.getAtividade());
            ps.setDouble(3, aluno.getDuracao());
            ps.setDouble(4, aluno.getCaloria());
            ps.execute();

        } catch (SQLException e) {
            System.out.println("Erro ao inserir no banco de dados\n" + e);
        }
    }

    public List<Aluno> listar() {
        List<Aluno> lista = new ArrayList<>();
        sql = "SELECT * FROM java_caloria";

        try(Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Aluno aluno = new Aluno();
                aluno.setId(rs.getInt("id"));
                aluno.setAluno(rs.getString("aluno"));
                aluno.setAtividade(rs.getString("atividade"));
                aluno.setDuracao(rs.getDouble("duracao"));
                aluno.setCaloria(rs.getDouble("caloria"));
                lista.add(aluno);
            }

        } catch (Exception e) {
            System.out.println("Erro ao listar java_caloria\n" + e);
        }

        return lista;
    }

}
