package calorias;

public class Aluno {
    private int id;
    private String aluno;
    private String atividade;
    private double duracao;
    private double caloria;

    @Override
    public String toString() {
        return String.format("Id = %d | Aluno = %s | Atividade = %s | Duração = %d | Calorias = %d");
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAluno() {
        return aluno;
    }

    public void setAluno(String aluno) {
        this.aluno = aluno;
    }

    public double getDuracao() {
        return duracao;
    }

    public void setDuracao(double duracao) {
        this.duracao = duracao;
    }

    public String getAtividade() {
        return atividade;
    }

    public void setAtividade(String atividade) {
        this.atividade = atividade;
    }

    public double getCaloria() {
        return caloria;
    }

    public void setCaloria(double caloria) {
        this.caloria = caloria;
    }
}