import calorias.Aluno;
import calorias.AlunoDAO;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        AlunoDAO dao = new AlunoDAO();
        Aluno aluno = new Aluno();

        aluno.setAluno("Jaimao");
        aluno.setAtividade("Teste");
        aluno.setDuracao(90);
        aluno.setCaloria(40);

        dao.inserir(aluno);

        List<Aluno> lista = dao.listar();
        double calorias = 0;

        System.out.println("---------------------- Dados da tabela ----------------------\n");
        for(Aluno a : lista) {
            System.out.println("ID = " + a.getId() + " | Aluno = " + a.getAluno() + " | Atividade = " + a.getAtividade() + " | Duração = " + a.getDuracao() + " | Caloria = " + a.getCaloria() + "\n");
        }

        System.out.println("---------------------- Gasto Calórico ----------------------\n");
        for(Aluno a : lista) {
            System.out.println("Aluno = " + a.getAluno() + " | Gasto calórico = " + a.getDuracao() * a.getCaloria() + "\n");
        }

    }
}
