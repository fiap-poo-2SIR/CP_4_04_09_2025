import java.text.DecimalFormat;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // inserindo corridas
        CorridaDAO dao = new CorridaDAO();
        //Corrida corrida1 = new Corrida(1L, "Juninho", 10.5, 15.500, 5.50);
        //dao.inserir(corrida1);
        //Corrida corrida2 = new Corrida(2L, "Jorge", 10.7, 14.9, 6.20);
        //dao.inserir(corrida2);

        // listando corridas
        System.out.println("\n----------------------------------");
        System.out.println("Dados listados");
        System.out.println("----------------------------------");
        List<Corrida> lista = dao.listar();
        for (Corrida corrida : lista) {
            System.out.println(
                    "ID: " + corrida.getId() +
                    "\nMotorista: " + corrida.getMotorista() +
                    "\nDistancia: " + corrida.getDistancia() +
                    "\nConsumo: " + corrida.getConsumo() +
                    "\nPreco: " + corrida.getPreco() +
                    "\n------------------------");
        }

        System.out.println("\n----------------------------------");
        System.out.println("Motorista e custo da corrida");
        System.out.println("----------------------------------");
        double custo = 0;
        DecimalFormat dc = new DecimalFormat("##,##0.00");
        for (Corrida corrida : lista) {
            custo = (corrida.getDistancia() / corrida.getConsumo()) * corrida.getPreco();
            System.out.println("Nome: " + corrida.getMotorista());
            System.out.println("Custo: " + dc.format(custo));
            System.out.println("------------------------");
        }

        Scanner x = new Scanner(System.in);
        String nome;
        double total = 0;

        System.out.print("Informe o nome a ser procurado: ");
        nome = x.next().toUpperCase();

        for (Corrida corrida : lista) {
            if (nome.equals(corrida.getMotorista().toUpperCase())) {
                total += custo;
            }
        }
        System.out.println("Gasto total: " + dc.format(total));
    }
}
