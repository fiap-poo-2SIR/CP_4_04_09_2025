package Conexao;

import Modelo.Caloria;
import Modelo.CaloriaDAO;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println(Conexao.conectar());

        CaloriaDAO dao = new CaloriaDAO();

//        Caloria caloria1 = new Caloria();
//        caloria1.setId(1L);
//        caloria1.setAluno("lucas");
//        caloria1.setAtividade("atividade 1");
//        caloria1.setDuracao(1.00);
//        caloria1.setCaloria(10.00);
//        dao.inserir(caloria1);
//
//        Caloria caloria2 = new Caloria();
//        caloria2.setId(2L);
//        caloria2.setAluno("lucas");
//        caloria2.setAtividade("atividade 2");
//        caloria2.setDuracao(1.00);
//        caloria2.setCaloria(10.00);
//        dao.inserir(caloria2);
//
//        Caloria caloria3 = new Caloria();
//        caloria3.setId(3L);
//        caloria3.setAluno("teste");
//        caloria3.setAtividade("atividade 1");
//        caloria3.setDuracao(1.00);
//        caloria3.setCaloria(100.00);
//        dao.inserir(caloria3);

        List<Caloria> listaCaloria = dao.listar();
        for (Caloria c : listaCaloria){
            System.out.println("ID: " + c.getId());
            System.out.println("Aluno: " + c.getAluno());
            System.out.println("Atividade: " + c.getAtividade());
            System.out.println("Duracao: " + c.getDuracao());
            System.out.println("Caloria: " + c.getCaloria());
            System.out.println("Gasto Calórico Total: " + (c.getDuracao() * c.getCaloria()));
            System.out.println("------------------------------");
        }


        String nomeBusca = "lucas";
        List<Caloria> listaBusca = dao.buscaAluno(listaCaloria, nomeBusca);
        CaloriaDAO dao2 = new CaloriaDAO();

        double totalGeralAluno = 0;
        totalGeralAluno = dao2.calculoTotal(listaBusca);
        System.out.println("Aluno: " + nomeBusca + "--> Gasto Total:" + totalGeralAluno );



    }
}
