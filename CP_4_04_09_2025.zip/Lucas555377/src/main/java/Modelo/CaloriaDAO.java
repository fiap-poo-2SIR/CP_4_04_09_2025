package Modelo;

import Conexao.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CaloriaDAO {
    private PreparedStatement ps;
    private ResultSet rs;
    private String sql;

    public void inserir(Caloria caloria){
        sql = "insert into java_caloria values (?, ?, ?, ?, ?)";
        try(Connection connection = Conexao.conectar()){
            ps = connection.prepareStatement(sql);
            ps.setLong(1, caloria.getId());
            ps.setString(2, caloria.getAluno());
            ps.setString(3, caloria.getAtividade());
            ps.setDouble(4, caloria.getDuracao());
            ps.setDouble(5, caloria.getCaloria());

            ps.execute();

        } catch (SQLException e) {
            System.out.println("Erro ao inserir no banco de dados\n" + e);
        }
    }

    public List<Caloria> listar(){
        List<Caloria> lista = new ArrayList<>();
        sql = "select * from java_caloria";
        try(Connection connection = Conexao.conectar()){
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

            while(rs.next()){
                Caloria caloria = new Caloria();
                caloria.setId(rs.getLong("id"));
                caloria.setAluno(rs.getString("aluno"));
                caloria.setAtividade(rs.getString("atividade"));
                caloria.setDuracao(rs.getDouble("duracao"));
                caloria.setCaloria(rs.getDouble("caloria"));
                lista.add(caloria);
            }
        }catch (Exception e){
            System.out.println("Erro ao listar dados\n" + e);
        }
            return lista;
    }



    public static List<Caloria> buscaAluno(List<Caloria> lista, String nome){
        List<Caloria> resultado = new ArrayList<>();
        for (Caloria c : lista){
            if (c.getAluno().equalsIgnoreCase(nome)){
                resultado.add(c);
            }
        }
        return resultado;
    }

    public static double calculoTotal(List<Caloria> resultado){
        double totalAcumulado = 0;
        double totalIdv = 0;
        for (Caloria c : resultado){
            totalIdv = c.getDuracao() * c.getCaloria();
            totalAcumulado = totalAcumulado + totalIdv;
        }
        return totalAcumulado;
    }
}
