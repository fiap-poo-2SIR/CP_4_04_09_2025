import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class GerenciadorCorridas {

    private static final String URL = "jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL";
    private static final String USUARIO = "rm555366";
    private static final String SENHA = "221201";


    public static void inserirRegistros() {
        System.out.println("--- 1. Inserindo Registros ---");
        String sql = "INSERT INTO java_corrida (id, nome_motorista, distancia, consumo, preco) VALUES (java_corrida_seq.NEXTVAL, ?, ?, ?, ?)";

        try (Connection conn = Conexao.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {


            pstmt.setString(1, "Ana");
            pstmt.setDouble(2, 150.5);
            pstmt.setDouble(3, 15.0);
            pstmt.setDouble(4, 5.50);
            pstmt.executeUpdate();

            pstmt.setString(1, "Bruno");
            pstmt.setDouble(2, 80.0);
            pstmt.setDouble(3, 8.2);
            pstmt.setDouble(4, 5.75);
            pstmt.executeUpdate();

            pstmt.setString(1, "Ana");
            pstmt.setDouble(2, 220.0);
            pstmt.setDouble(3, 21.5);
            pstmt.setDouble(4, 5.45);
            pstmt.executeUpdate();

            System.out.println(" Registros inseridos com sucesso!");

        } catch (SQLException e) {
            System.err.println(" Erro de SQL ao inserir registros: " + e.getMessage());
        } catch (NullPointerException e) {
            System.err.println(" Falha na conexão. A operação foi cancelada. Verifique suas credenciais na classe Conexao.");
        }
        System.out.println();
    }

    public static void listarTodos() {
        System.out.println("--- 2. Listando Todos os Dados ---");
        String sql = "SELECT id, nome_motorista, distancia, consumo, preco FROM java_corrida ORDER BY id";

        try (Connection conn = Conexao.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                System.out.printf("ID: %d, Motorista: %s, Distância: %.2f km, Consumo: %.2f L, Preço/L: R$ %.2f\n",
                        rs.getInt("id"),
                        rs.getString("nome_motorista"),
                        rs.getDouble("distancia"),
                        rs.getDouble("consumo"),
                        rs.getDouble("preco"));
            }

        } catch (SQLException e) {
            System.err.println(" Erro de SQL ao listar dados: " + e.getMessage());
        } catch (NullPointerException e) {
            System.err.println(" Falha na conexão. A operação foi cancelada.");
        }
        System.out.println();
    }

    public static void imprimirCustoCorrida() {
        System.out.println("--- 3. Custo por Corrida ---");
        String sql = "SELECT nome_motorista, (distancia * preco) AS custo_corrida FROM java_corrida";

        try (Connection conn = Conexao.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                System.out.printf("Motorista: %s, Custo da Corrida: R$ %.2f\n",
                        rs.getString("nome_motorista"),
                        rs.getDouble("custo_corrida"));
            }

        } catch (SQLException e) {
            System.err.println(" Erro de SQL ao calcular custo por corrida: " + e.getMessage());
        } catch (NullPointerException e) {
            System.err.println(" Falha na conexão. A operação foi cancelada.");
        }
        System.out.println();
    }

    public static void imprimirGastoTotalPorMotorista() {
        System.out.println("--- 4. Gasto Total por Motorista ---");
        String sql = "SELECT nome_motorista, SUM(distancia * preco) AS gasto_total " +
                "FROM java_corrida " +
                "GROUP BY nome_motorista " +
                "ORDER BY nome_motorista";

        try (Connection conn = Conexao.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                System.out.printf("Motorista: %s, Gasto Total: R$ %.2f\n",
                        rs.getString("nome_motorista"),
                        rs.getDouble("gasto_total"));
            }

        } catch (SQLException e) {
            System.err.println(" Erro de SQL ao calcular gasto total por motorista: " + e.getMessage());
        } catch (NullPointerException e) {
            System.err.println(" Falha na conexão. A operação foi cancelada.");
        }
        System.out.println();
    }

    public static void imprimirGastoTotal() {
        System.out.println("--- 5. Gasto Total Geral ---");
        String sql = "SELECT SUM(distancia * preco) AS total_geral FROM java_corrida";

        try (Connection conn = Conexao.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                System.out.printf("O gasto total com todas as corridas foi de: R$ %.2f\n",
                        rs.getDouble("total_geral"));
            }

        } catch (SQLException e) {
            System.err.println(" Erro de SQL ao calcular gasto total geral: " + e.getMessage());
        } catch (NullPointerException e) {
            System.err.println(" Falha na conexão. A operação foi cancelada.");
        }
        System.out.println();
    }

    public static void main(String[] args) {

        inserirRegistros();
        listarTodos();
        imprimirCustoCorrida();
        imprimirGastoTotalPorMotorista();
        imprimirGastoTotal();
    }
}