import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class caloriasDAO {
    private PreparedStatement ps;
    private ResultSet rs;
    private String slq;
    private int parameterIndex;

    public caloriasDAO(PreparedStatement ps, ResultSet rs, String slq, int parameterIndex) {
        this.ps = ps;
        this.rs = rs;
        this.slq = slq;
        this.parameterIndex = parameterIndex;
    }

    public caloriasDAO() {

    }

    public void inserir(Calorias Caloria ){
        slq = "inset java_calorias values (seqd.nextval,?,?,?,?)";
        try (Connection connection= (conexao.conexao)){



        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    private static void getcalorias() {
    }
}
