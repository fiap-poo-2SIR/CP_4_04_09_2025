import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class conexao {
    public static conexao conexão;
    public static Connection conexao;

    public class Conexao {
        private static String URL = "jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL";
        private static String USER = "";
        private static String PASSWORD = "";

        private void conexao() {}

        public static Connection conectar() {
            try {
                return DriverManager.getConnection(URL, USER, PASSWORD);
            }
            catch(SQLException e) {
                System.out.println("Erro ao conectar no banco\n" + e);
            }
            return null;
        }
    }
}
