public class Calorias {
    private long getid  ;
    private String aluno;
    private double atividade;
    private double valor;
    private String duracao;

    long String;
    public void Calorias {

    }

    private static Calorias createCalorias(long id, double valor, double atividade, String aluno) {
        return new Calorias(id, valor, atividade, aluno);
    }


    public long getGetid() {
        return getid;
    }

    public String getDuracaouracao() {
        return duracao;
    }

    private Calorias(long id, double valor, double atividade, String aluno) {
        this.getid = id;
        this.valor = valor;
        this.atividade = atividade;
        this.aluno = aluno;
    }



    public Calorias(long id, String aluno, double atividade) {
        this.getid = id;
        this.aluno = aluno;
        this.atividade = atividade;
    }



    private


    public void setId(long id) {
        this.getid = id;
    }

    public void setAluno(String aluno) {
        this.aluno = aluno;
    }

    public void setAtividade(double atividade) {
        this.atividade = atividade;
    }

    public long getId() {
        return getid;
    }

    public String getAluno() {
        return aluno;
    }

    public double getAtividade() {
        return atividade;
    }

    public Calorias() {
        this.getid = getid;
        this.aluno = aluno;
        this.atividade = atividade;
    }

    public double getValor() {
        return valor;
    }
}



