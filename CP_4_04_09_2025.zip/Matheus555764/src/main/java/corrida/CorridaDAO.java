package corrida;

import main.Conexao;
import corrida.Corrida;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CorridaDAO {
    public void inserir (Corrida corrida){
        String sql = "INSERT INTO java_corrida (id, motorista, distancia, consumo, preco) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = Conexao.conectar();
             PreparedStatement ps = connection.prepareStatement(sql)){
             ps.setInt(1, corrida.getId());
             ps.setString(2, corrida.getMotorista());
             ps.setDouble(3, corrida.getDistancia());
             ps.setDouble(4, corrida.getConsumo());
             ps.setDouble(5, corrida.getPreco());
             ps.executeUpdate();
             System.out.println("Corrida do motorista inserida com sucesso");
        } catch (SQLException e) {
            System.out.println("Erro ao inserir a corrida: " + e.getMessage());
        }

    }

    public List<Corrida> listarTudo(){
        List <Corrida> corridas = new ArrayList<>();
        String sql = "SELECT id, motorista, distancia, consumo, preco FROM java_corrida ORDER BY id";
     try (Connection connection = Conexao.conectar();
          Statement st = connection.createStatement();
          ResultSet rs = st.executeQuery(sql)){
         while (rs.next()){
             corridas.add(new Corrida(rs.getInt("id"), rs.getString("motorista"),
                     rs.getDouble("distancia"), rs.getDouble("consumo"),
                     rs.getDouble("preco")));
         }
     } catch (SQLException e) {
         System.out.println("Erro ao listar corridas: " + e.getMessage());
     }
     return corridas;
    }
}
