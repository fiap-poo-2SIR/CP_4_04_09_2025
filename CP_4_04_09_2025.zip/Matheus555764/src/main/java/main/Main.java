package main;

import corrida.Corrida;
import corrida.CorridaDAO;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        CorridaDAO corridaDAO = new CorridaDAO();
        System.out.println("\n Inserindo registros da corrida");
        corridaDAO.inserir(new Corrida(1, "Cleiton", 1000.50, 500.35, 300.67));
        corridaDAO.inserir(new Corrida(2, "Isabela", 2000.25, 700.67, 600.90));
        corridaDAO.inserir(new Corrida(3, "Túlio", 500.30, 900.30, 500.67));
        corridaDAO.inserir(new Corrida(4, "Casper", 5000.60, 800.70, 350.56));
        corridaDAO.inserir(new Corrida(5, "Alexander", 150.69, 200.90, 900.76));

        System.out.println("\nListando corridas...");
        List <Corrida> todasAsCorridas = corridaDAO.listarTudo();
        for(Corrida c : todasAsCorridas){
            System.out.println(c.getId());
            System.out.println(c.getMotorista());
            System.out.println(c.getDistancia() + " metros");
            System.out.println(c.getConsumo() + " litros");
            System.out.println(c.getPreco() + " por litro");
        }
    }
}
