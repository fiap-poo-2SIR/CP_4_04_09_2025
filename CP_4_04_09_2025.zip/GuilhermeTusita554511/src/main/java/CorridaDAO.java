import java.sql.*;
import java.util.*;

public class CorridaDAO {

    public void inserir(Corrida c) {
        String sql = "INSERT INTO java_corrida VALUES (seq_corrida.nextVal, ?, ?, ?, ?)";
        try (Connection cn = Conexao.conectar();
            PreparedStatement ps = cn.prepareStatement(sql)){
            ps.setString(1, c.getMotorista());
            ps.setDouble(2, c.getDistancia());
            ps.setDouble(3, c.getConsumo());
            ps.setDouble(4, c.getPreco());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir!", e);
        }
    }

    public List<Corrida> listar() {
        List<Corrida> lista = new ArrayList<>();
        String sql = "SELECT id, motorista, distancia, consumo, preco from java_corrida";
        try (Connection cn = Conexao.conectar();
            PreparedStatement ps = cn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()){
            while (rs.next()) {
                Corrida c = new Corrida();
                c.setId(rs.getLong("id"));
                c.setMotorista(rs.getString("motorista"));
                c.setDistancia(rs.getDouble("distancia"));
                c.setConsumo(rs.getDouble("consumo"));
                c.setPreco(rs.getDouble("preco"));
                lista.add(c);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar!", e);
        }
        return lista;
    }

    public String custoCorrida(int id) {
        String sql = "SELECT id, motorista, distancia, consumo, preco from java_corrida where id = '"+id+"'";
        try (Connection cn = Conexao.conectar();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()){
            while (rs.next()) {
                return (rs.getString("motorista") + " | Custo da corrida: " + (rs.getDouble("distancia") / rs.getDouble("consumo")) * rs.getDouble("preco"));
            }
            } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar!", e);
        }
        return "erro";
    }

    public Double totalMotorista(String motorista) {
        List<String> tm = new ArrayList<>();
        double custo = 0;
        double somaTotal = 0;
        String sql = "SELECT id, motorista, distancia, consumo, preco from java_corrida where motorista = '"+motorista+"'";
        try (Connection cn = Conexao.conectar();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()){
            while (rs.next()) {
                double dist = rs.getDouble("distancia");
                double con = rs.getDouble("consumo");
                double pre = rs.getDouble("preco");
                custo = (dist/con) * pre;
                somaTotal += custo;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar o total do motorista!", e);
        }
        return somaTotal;
    }

}
