public class Main {

    public static void main(String[] args) {

        CorridaDAO dao = new CorridaDAO();

        dao.inserir(new Corrida("Alan", 1000, 10, 5));
        dao.inserir(new Corrida("Bruno", 20, 20, 20));
        dao.inserir(new Corrida("Carlos", 30, 30, 30));
        dao.inserir(new Corrida("Darlan", 40, 40, 40));

        System.out.println("Todas as corridas:");
        for (Corrida c : dao.listar()) {
            System.out.println(c.getId() + " | " + c.getMotorista() + " | " + c.getDistancia() + " | " + c.getConsumo() + " | " + c.getPreco());
        }

        System.out.println("Custo da corrida do motorista: " + dao.custoCorrida(48));

        System.out.println("Gasto total:"+dao.totalMotorista("Alan")); //Dava pra melhorar trocando o return double pro String e trazer o nome, mas n deu tempo!

    }

}
