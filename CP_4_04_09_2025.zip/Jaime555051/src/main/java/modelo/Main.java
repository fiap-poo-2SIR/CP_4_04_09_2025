package modelo;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DecimalFormat mask = new DecimalFormat("R$#.00");
        CorridaDAO dao = new CorridaDAO();

        Corrida a = new Corrida();
        a.setId(1);
        a.setMotorista("Selmini");
        a.setDistancia(10.0);
        a.setConsumo(2.5);
        a.setPreco(100.00);
        dao.inserir(a);

        Corrida b = new Corrida();
        b.setId(2);
        b.setMotorista("Jaime");
        b.setDistancia(25.0);
        b.setConsumo(8.5);
        b.setPreco(250.00);
        dao.inserir(b);

        Corrida c = new Corrida();
        c.setId(3);
        c.setMotorista("Jaime");
        c.setDistancia(10.0);
        c.setConsumo(6.5);
        c.setPreco(125.50);
        dao.inserir(c);

        List<Corrida> lista = dao.listar();
        for(Corrida ca : lista) {
            System.out.println("ID: " + ca.getId() + "\nMotorista: "
                    + ca.getMotorista() + "\nDistância: " + ca.getDistancia()
                    + "\nConsumo: " + ca.getConsumo() + "\nPreço: " + mask.format(ca.getPreco()));
            System.out.println();
        }

        double custo;
        for(Corrida ca : lista) {
            custo = (ca.getDistancia() / ca.getConsumo()) * ca.getPreco();
            System.out.println("O custo da corrida (ID: " + ca.getId() + ") do motorista " + ca.getMotorista()
                    + " foi de " + mask.format(custo));

            custo = 0;
        }
    }
}