package org.example.entities;

import org.example.Conexao;
import org.example.models.Corrida;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CorridaDAO {
    public static void salvar(Corrida corrida) {
        Connection c = Conexao.conectar();
        try {
            String sql = "INSERT INTO java_corrida VALUES (?, ?, ?, ?, ?)";

            if (c != null) {
                PreparedStatement ps = c.prepareStatement(sql);
                ps.setInt(1, corrida.getId());
                ps.setString(2, corrida.getMotorista());
                ps.setDouble(3, corrida.getDistancia());
                ps.setDouble(4, corrida.getConsumo());
                ps.setDouble(5, corrida.getPreco());

                ps.executeUpdate();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        finally {
            if (c != null) {
                try {
                    c.close();
                } catch (SQLException e) {
                    System.out.println("Erro ao fechar conexão.");
                }
            }
        }
    }

    public static List<Corrida> listarTodas() {
        List<Corrida> corridas = new ArrayList<>();
        Connection c = Conexao.conectar();
        try {
            String sql = "SELECT * FROM java_corrida";

            if (c != null) {
                PreparedStatement ps = c.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();

                while(rs.next()) {
                    corridas.add(
                            new Corrida (
                                rs.getInt("id"),
                                rs.getString("motorista"),
                                rs.getDouble("distancia"),
                                rs.getDouble("consumo"),
                                rs.getDouble("preco")
                            )
                    );
                }

                ps.executeUpdate();
            }

            return corridas;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        finally {
            if (c != null) {
                try {
                    c.close();
                } catch (SQLException e) {
                    System.out.println("Erro ao fechar conexão.");
                }
            }
        }
    }

    public static List<Corrida> listarCorridasDeMotorista(String nomeMotorista) {
        List<Corrida> corridas = new ArrayList<>();
        Connection c = Conexao.conectar();
        try {
            String sql = "SELECT * FROM java_corrida WHERE motorista = ?";

            if (c != null) {
                PreparedStatement ps = c.prepareStatement(sql);
                ps.setString(1, nomeMotorista);
                ResultSet rs = ps.executeQuery();

                while(rs.next()) {
                    corridas.add(
                            new Corrida (
                                    rs.getInt("id"),
                                    rs.getString("motorista"),
                                    rs.getDouble("distancia"),
                                    rs.getDouble("consumo"),
                                    rs.getDouble("preco")
                            )
                    );
                }

                ps.executeUpdate();
            }

            return corridas;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        finally {
            if (c != null) {
                try {
                    c.close();
                } catch (SQLException e) {
                    System.out.println("Erro ao fechar conexão.");
                }
            }
        }
    }
}
