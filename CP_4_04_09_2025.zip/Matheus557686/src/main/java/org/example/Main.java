package org.example;

import org.example.entities.CorridaDAO;
import org.example.models.Corrida;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("0.00");

        List<Corrida> corridas = new ArrayList<>();
        corridas.add(new Corrida(1, "Selmini", 10, 2, 2));
        corridas.add(new Corrida(2, "Matheus", 55.5, 5.8, 8.80));

        for (int i = 0; i < corridas.size(); i++) {
            // 1. Insira registros na tabela
            CorridaDAO.salvar(corridas.get(i));
        }

        List<Corrida> corridasGravadas = CorridaDAO.listarTodas();
        for (int i = 0; i < corridasGravadas.size(); i++) {
            // 2. Liste todos os dados armazenados na tabela
            // 3. Imprima o nome do motorista e o custo da corrida
            System.out.println(corridasGravadas.get(i).toString());
        }

        String nomeMotorista = s.next();
        List<Corrida> corridasGravadasDoMotorista = CorridaDAO.listarCorridasDeMotorista(nomeMotorista);
        System.out.println("Digite o nome do motorista para saber seu gasto total");
        double gastoTotal = 0;
        for (int i = 0; i < corridasGravadasDoMotorista.size(); i++) {
            gastoTotal += corridasGravadasDoMotorista.get(i).getCusto();
        }
        // 4. Imprima o gasto total por motorista
        System.out.println("O motorista " + nomeMotorista + " gastou R$" + df.format(gastoTotal));
    }
}
