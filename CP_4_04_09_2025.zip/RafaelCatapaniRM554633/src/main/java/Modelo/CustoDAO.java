package Modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CustoDAO {

    private PreparedStatement ps;
    private String sql;
    private ResultSet rs;


}
