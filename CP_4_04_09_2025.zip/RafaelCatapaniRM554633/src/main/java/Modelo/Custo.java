package Modelo;

public class Custo {

    private String motorista;
    private int id;
    private double distancia;
    private double consumo;
    private double preco;

    public Custo(String motorista, int id, double distancia, double preco, double consumo) {
        this.motorista = motorista;
        this.id = id;
        this.distancia = distancia;
        this.preco = preco;
        this.consumo = consumo;
    }

    public String getMotorista() {
        return motorista;
    }

    public void setMotorista(String motorista) {
        this.motorista = motorista;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getDistancia() {
        return distancia;
    }

    public void setDistancia(double distancia) {
        this.distancia = distancia;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public double getConsumo() {
        return consumo;
    }

    public void setConsumo(double consumo) {
        this.consumo = consumo;
    }
}
