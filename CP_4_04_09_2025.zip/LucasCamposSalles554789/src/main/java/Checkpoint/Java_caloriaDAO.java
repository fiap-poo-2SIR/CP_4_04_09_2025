package Checkpoint;

import Conexao.Conexao;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Java_caloriaDAO {
    private PreparedStatement ps;
    private String sql;
    private ResultSet rs;


    public void inserir(Java_caloria caloria){
        sql = "INSERT INTO java_caloria (id, aluno, atividade, duracao, caloria) VALUES (?, ?, ?, ?, ?)";
        try(Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            ps.setLong(1, caloria.getId());
            ps.setString(2, caloria.getAluno());
            ps.setString(3, caloria.getAtividade());
            ps.setDouble(4, caloria.getDuracao());
            ps.setDouble(5, caloria.getCaloria());
            ps.execute();
        }
        catch (SQLException e){
            System.out.println("Erro ao inserir calorias no banco de dados: " +e.getMessage());
        }
    }
    public List<Java_caloria> listar(){
        List<Java_caloria> lista = new ArrayList<>();
        sql = "SELECT id,aluno,atividade,duracao,caloria FROM java_caloria";
        try(Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()){
                Java_caloria caloria = new Java_caloria();
                caloria.setId(rs.getLong("id"));
                caloria.setAluno(rs.getString("aluno"));
                caloria.setAtividade(rs.getString("atividade"));
                caloria.setDuracao(rs.getDouble("duracao"));
                caloria.setCaloria(rs.getDouble("caloria"));
                lista.add(caloria);
            }
        }
        catch (SQLException e){
            System.out.println("Erro ao listar tarefas: " +e.getMessage());
        }
        return lista;
    }
    public void listaGasto(){
        List<Java_caloria> lista = listar();
        double gasto =0;
        for (Java_caloria caloria : lista){
            gasto = caloria.getDuracao()*caloria.getCaloria();
            System.out.println("Nome: " +caloria.getAluno() +" Gasto: " +gasto);
        }
    }
    public void listaCalAluno(){
        List<Java_caloria> lista = listar();
        List<String> nomes = new ArrayList<>();
        double gasto;
        for (Java_caloria caloria : lista){
            nomes = Collections.singletonList(caloria.getAluno());
            gasto = caloria.getCaloria();
            if (caloria.getAluno().equalsIgnoreCase(String.valueOf(nomes))){
                gasto += caloria.getDuracao()*caloria.getCaloria();
                caloria.setCaloria(gasto);
            } else {
                gasto = caloria.getDuracao()*caloria.getCaloria();
            }
        }
;

    }




}
