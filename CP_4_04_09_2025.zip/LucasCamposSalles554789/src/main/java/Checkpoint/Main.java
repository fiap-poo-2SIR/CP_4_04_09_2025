package Checkpoint;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        Java_caloriaDAO JDAO = new Java_caloriaDAO();
        Java_caloria cal= new Java_caloria();
        cal.setId(6L);
        cal.setAluno("Lucas");
        cal.setAtividade("Corrida");
        cal.setDuracao(1.5);
        cal.setCaloria(2.0);
        JDAO.inserir(cal);


        List<Java_caloria> listaCaloria = JDAO.listar();
        if(listaCaloria.isEmpty()){
            System.out.println("Ta vazia a lista.");
        } else {
            for (Java_caloria caloria : listaCaloria){
                System.out.println("id:" +caloria.getId() +" Nome:" +caloria.getAluno() +" Atividade: " +caloria.getAtividade() +" Duracao em min:" +caloria.getDuracao() +" Calorias: " +caloria.getCaloria());
            }
        }

        JDAO.listaGasto();
        JDAO.listaCalAluno();
    }
}
