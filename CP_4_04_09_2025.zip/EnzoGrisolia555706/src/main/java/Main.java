import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws SQLException {
        CorridaDAO dao = new CorridaDAO();

        List<Corrida> ListarCorrida = dao.listar();
        for (Corrida c : ListarCorrida) {
            System.out.println("ID: " + c.getId());
            System.out.println("Motorista: " + c.getMotorista());
            System.out.println("Distancia: " + c.getDistancia());
            System.out.println("Consumo: " + c.getConsumo());
            System.out.println("Preço: " + c.getPreco());
        }

        for (Corrida c : dao.listar()) {
            System.out.println(c.getMotorista() + "Custo: " + (c.getDistancia() * c.getPreco()) / c.getConsumo());
        }

        Map<String, Double> totais = dao.gastoTotalPorMotorista();
        for (String motorista : totais.keySet()) {
            System.out.println(motorista + " - Total: " + totais.get(motorista));
        }
    }
}
