public class Corrida {
    private int id;
    private String motorista;
    private double distancia;
    private double consumo;
    private double preco;

    public Corrida(int id, String motorista, double distancia, double consumo, double preco) {
        this.id = id;
        this.motorista = motorista;
        this.distancia = distancia;
        this.consumo = consumo;
        this.preco = preco;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMotorista() {
        return motorista;
    }

    public void setMotorista(String motorista) {
        this.motorista = motorista;
    }

    public double getDistancia() {
        return distancia;
    }

    public void setDistancia(double distancia) {
        this.distancia = distancia;
    }

    public double getConsumo() {
        return consumo;
    }

    public void setConsumo(double consumo) {
        this.consumo = consumo;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }
}
