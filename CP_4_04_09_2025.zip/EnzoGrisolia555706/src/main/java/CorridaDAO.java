import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CorridaDAO {
    private Connection conectar () throws SQLException {
        return DriverManager.getConnection(
                "jdbc:oracle:thin:@oracle:fiap.com.br:1521:ORCL",
                "RM555706",
                "130305"
        );
    }

    public void inserir (Corrida corrida) throws SQLException {
        String sql = "INSERT INTO java_corrida values(?, ?, ?, ?, ?)";
        try(Connection con = conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1,corrida.getId());
            ps.setString(2, corrida.getMotorista());
            ps.setDouble(3, corrida.getDistancia());
            ps.setDouble(4, corrida.getConsumo());
            ps.setDouble(5, corrida.getPreco());
            ps.executeUpdate();
            System.out.println("Venda inserida com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Corrida> listar () throws SQLException {
        List<Corrida>lista = new ArrayList<>();
        String sql = "Select * from java_corrida";
        try(Connection con = conectar(); Statement st = con.createStatement();ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Corrida(
                        rs.getInt("id"),
                        rs.getString("motorista"),
                        rs.getDouble("distancia"),
                        rs.getDouble("consumo"),
                        rs.getDouble("preco")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public Map<String, Double> gastoTotalPorMotorista() throws SQLException {
        Map<String, Double> mapa = new HashMap<>();
        String sql = "Select motorista, consumo, distancia, preco from java_corrida";
        try (Connection con = conectar(); Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                String motorista = rs.getString("motorista");
                Double distancia = rs.getDouble("distancia");
                Double consumo = rs.getDouble("consumo");
                Double preco = rs.getDouble("preco");
                mapa.put(motorista, mapa.getOrDefault(motorista, 0.0));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return mapa;
    }
}
