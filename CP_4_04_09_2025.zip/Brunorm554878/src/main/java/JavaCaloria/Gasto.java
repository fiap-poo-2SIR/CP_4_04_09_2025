package JavaCaloria;

public class Gasto {
    private long id;
    private String aluno;
    private Double duracao;
    private double caloria;

    public Long getid(){return id;}

    public void setId(long id) {
        this.id = id;
    }

    public void setAluno(String aluno) {
        this.aluno = aluno;
    }

    public void setDuracao(Double duracao) {
        this.duracao = duracao;
    }

    public void setCaloria(double caloria) {
        this.caloria = caloria;
    }

    public long getId() {
        return id;
    }

    public String getAluno() {
        return aluno;
    }

    public Double getDuracao() {
        return duracao;
    }

    public double getCaloria() {
        return caloria;
    }
}
