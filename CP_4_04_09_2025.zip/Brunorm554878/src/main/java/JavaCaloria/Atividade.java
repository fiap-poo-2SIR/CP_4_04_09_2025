package JavaCaloria;

public class Atividade {
    private long minutos;
    private String atividade ;

    public long minutos() {
        long minutos = 60;
        return minutos;
    }
    public String getAtividade() {
        return atividade;
    }

    public Atividade(long minutos, String atividade ){

        this.atividade = atividade;

    }

}
