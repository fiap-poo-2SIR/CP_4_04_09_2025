package conexao;

import JavaCaloria.Atividade;

public class Main {
    public static void main(String[] args) {
        Atividade atividade = new Atividade(10, "futebol");




    }
}
