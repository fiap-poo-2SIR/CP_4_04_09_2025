package br.fiap.conexao;
import java.sql.*;

import static br.fiap.conexao.Conexao.conectar;

public class App
{
    public static void main( String[] args )
    {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        }
        catch (Exception e){
            System.out.println("Não localizado");
        }

        try {
            Connection c= conectar();
            System.out.println("conectado");
            String sql=" INSERT INTO java_corrida (id, motorista, distancia, consumo, preco) VALUES (?,?,?,?,?)";
            PreparedStatement ps= c.prepareStatement(sql);{
                ps.setInt(1,100);
                ps.setString(2,"Carlos");
                ps.setDouble(3,150);
                ps.setDouble(4,20);
                ps.setDouble(5,5.50);
                ps.executeUpdate();
            }

            sql="SELECT * FROM java_corrida";
            Statement st=c.createStatement();
            ResultSet rs=st.executeQuery(sql);{
                System.out.println("\n---Dados da tabela---");
                while (rs.next()){
                    System.out.printf("ID:%d|Motorista:%s|Distancia:%.2f|Consumo:%.2f|Preco:%.2f|\n",
                    rs.getInt("id"),
                    rs.getString("motorista"),
                    rs.getDouble("distancia"),
                    rs.getDouble("consumo"),
                    rs.getDouble("preco"));
                }
            }
        }
        catch (Exception e){
            System.out.println("Erro");
        }


    }
}
