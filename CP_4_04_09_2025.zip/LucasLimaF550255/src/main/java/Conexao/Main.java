package Conexao;

import Modelo.Java_Corrida;
import Modelo.Java_corridaDAO;

import java.util.List;

public class Main {
        public static void main(String[] args) {
            double custo;

            Java_corridaDAO dao = new Java_corridaDAO();
            Java_Corrida javaCorrida =new Java_Corrida(2, "Pedro",7.0,10.0,9.0);
            dao.inserir(javaCorrida);

            List<Java_Corrida> lista = dao.listar();
            for (Java_Corrida java_corrida : lista){
                System.out.println("id motorista" + java_corrida.getId_corrida()+ "nome" + java_corrida.getNm_motorista() + "Distancia" + java_corrida.getDistancia()+ "Consumo" + java_corrida.getConsumo()+"preco gasolina" +java_corrida.getPreco()) ;

            custo = (javaCorrida.getDistancia()/ javaCorrida.getConsumo()) * javaCorrida.getPreco();
            System.out.println("O custo foi de " + custo);

            }

        }
}
