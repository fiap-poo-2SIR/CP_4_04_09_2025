package Modelo;

public class Java_Corrida {
    private int id_corrida;
    private String nm_motorista;
    private Double distancia;
    private Double consumo;
    private Double preco;

    public Java_Corrida(int id_corrida, String nm_motorista, Double distancia, Double consumo, Double preco) {
        this.id_corrida = id_corrida;
        this.nm_motorista = nm_motorista;
        this.distancia = distancia;
        this.consumo = consumo;
        this.preco = preco;

    }

    public int getId_corrida() {
        return id_corrida;
    }

    public void setId_corrida(int id_corrida) {
        this.id_corrida = id_corrida;
    }

    public String getNm_motorista() {
        return nm_motorista;
    }

    public void setNm_motorista(String nm_motorista) {
        this.nm_motorista = nm_motorista;
    }

    public Double getDistancia() {
        return distancia;
    }

    public void setDistancia(Double distancia) {
        this.distancia = distancia;
    }

    public Double getConsumo() {
        return consumo;
    }

    public void setConsumo(Double consumo) {
        this.consumo = consumo;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }
}
