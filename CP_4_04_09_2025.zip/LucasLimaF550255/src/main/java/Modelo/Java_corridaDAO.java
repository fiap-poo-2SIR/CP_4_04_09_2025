package Modelo;

import Conexao.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Java_corridaDAO {
    private PreparedStatement ps;
    private ResultSet rs;
    private String sql;

    public void inserir (Java_Corrida java_corrida){
        sql = "Insert into JAVA_CORRIDA values (?,?,?,?,?)";


        try(Connection connection = Conexao.conectar()){
            ps = connection.prepareStatement(sql);
            ps.setInt(1,java_corrida.getId_corrida());
            ps.setString(2, java_corrida.getNm_motorista());
            ps.setDouble(3,java_corrida.getDistancia());
            ps.setDouble(4,java_corrida.getConsumo());
            ps.setDouble(5,java_corrida.getPreco());
        }
        catch (SQLException e){
            System.out.println("Erro ao inserir no Banco de Dados\n" + e);
        }
    }


    public List<Java_Corrida> listar(){
        List<Java_Corrida> lista = new ArrayList<>();
        sql = "select * from JAVA_CORRIDA";

        try(Connection connection = Conexao.conectar()){
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()){
                lista.add(new Java_Corrida(rs.getInt("id_corrida"),rs.getString("nm_motorista"),rs.getDouble("Distancia"),rs.getDouble("Consumo"),rs.getDouble("preço")));
            }
        }
        catch (SQLException e){
            System.out.println("Erro ao listar java_corrida\n" + e);
        }
        return lista;
    }
}
