package Modelo;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        CorridaDAO dao = new CorridaDAO();
        Corrida corrida = new Corrida();
           dao.inserir(new Corrida(2334, "carlos", 20.0, 2.0, 1.0));
           dao.inserir(new Corrida(2334, "carlos", 20.0, 2.0, 1.0));
           //dao.inserir(new Corrida());

           System.out.println("--- LISTA ---");
           List<Corrida> lista = dao.listar();
           for (Corrida c : lista) {
               System.out.println(c);
           }
    }
}
