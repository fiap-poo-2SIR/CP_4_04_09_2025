import java.util.List;

public class TesteCorrida {
    public static void main(String[] args) {
        CorridaDAO dao = new CorridaDAO();
        //Teste de Inserção
//        Corrida corrida = new Corrida("David", 10, 2, 10);
//        dao.inserir(corrida);

        //Teste de Consulta
//        System.out.println("Lista de corridas");
//        List<Corrida> lista = dao.consultar();
//        for (Corrida c : lista) {
//            System.out.println();
//            System.out.println(c);
//        }


        //Teste Motorista e o Custo
//        System.out.println();
//        List<Corrida> listaCusto = dao.consultar();
//        for (Corrida cc : listaCusto) {
//            System.out.println("Motorista: " + cc.getMotorista());
//            System.out.println("Custo: " + cc.custoCorrida(cc));
//            System.out.println();
//        }



        //Teste gasto total
//        System.out.println("\nGasto total: ");
//        Corrida c = new Corrida();
//////    Se digitar o nome errado nao vai trazer ksksk
//        c.setMotorista("Renan");
//        List<Corrida> gasto = dao.consultar();
//        String nome = "";
//        double gastoTotal = 0;
//        for(Corrida cg: gasto) {
//            nome = cg.getMotorista();
//            gastoTotal += cg.custoCorrida(cg);
////          System.out.println("Gasto total = " + cg.calcularTotal(gasto));
//            System.out.println();
//        }
//        System.out.println("Nome: " + nome);
//        System.out.println("Gasto total = " + gastoTotal);



    }
}
