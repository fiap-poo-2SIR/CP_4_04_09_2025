import java.util.List;

public class Corrida {
    private Long id;
    private String motorista;
    private double distancia;
    private double consumo;
    private double preco;

    public Corrida () {}

    public Corrida(String motorista, double distancia, double consumo, double preco) {
        this.motorista = motorista;
        this.distancia = distancia;
        this.consumo = consumo;
        this.preco = preco;
    }

    public double custoCorrida(Corrida c) {
        double custo = (c.getDistancia() / c.getConsumo()) * c.getPreco();
        return custo;
    }

//    public double calcularTotal(List<Corrida> l) {
//        double gasto = 0;
//        for (Corrida c : l) {
//            gasto += c.custoCorrida(c);
//        }
//        return gasto;
//    }

    @Override
    public String toString() {
        return "\nid=" + id +
                "\nmotorista='" + motorista + '\'' +
                "\ndistancia=" + distancia +
                "\nconsumo=" + consumo +
                "\npreco=" + preco;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMotorista() {
        return motorista;
    }

    public void setMotorista(String motorista) {
        this.motorista = motorista;
    }

    public double getDistancia() {
        return distancia;
    }

    public void setDistancia(double distancia) {
        this.distancia = distancia;
    }

    public double getConsumo() {
        return consumo;
    }

    public void setConsumo(double consumo) {
        this.consumo = consumo;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }
}
