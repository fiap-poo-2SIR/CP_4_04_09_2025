import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CorridaDAO {
    private PreparedStatement ps;
    private String sql;

    public void inserir(Corrida corrida) {
        sql = "INSERT INTO java_corrida (id, motorista, distancia, consumo, preco) VALUES (seqco.nextval, ?, ?, ?, ?)";
        try (Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            ps.setString(1, corrida.getMotorista());
            ps.setDouble(2, corrida.getDistancia());
            ps.setDouble(3, corrida.getConsumo());
            ps.setDouble(4, corrida.getPreco());
            ps.execute();
            System.out.println("Inserção realizada com sucesso! ");
        } catch (SQLException e) {
            System.out.println("Problema ao tentar inserir dados no Banco de Dados! ");
        }
    }

    public List<Corrida> consultar() {
        List<Corrida> lista = new ArrayList<>();
        ResultSet rs = null;
        sql = "SELECT * FROM java_corrida ORDER BY id";
        try (Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Corrida corrida = new Corrida();
                corrida.setId(rs.getLong("id"));
                corrida.setMotorista(rs.getString("motorista"));
                corrida.setDistancia(rs.getDouble("distancia"));
                corrida.setConsumo(rs.getDouble("consumo"));
                corrida.setPreco(rs.getDouble("preco"));
                lista.add(corrida);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao tentar consultar no Banco de Dados");
        }
        return lista;
    }

    public List<Corrida> getporMotorista() {
        List<Corrida> lista = new ArrayList<>();
        ResultSet rs = null;
        sql = "SELECT * FROM java_corrida WHERE motorista = ?";
        try(Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Corrida corrida = new Corrida();
                corrida.setMotorista(rs.getString("motorista"));
                lista.add(corrida);
            }
        }catch (SQLException e) {
            System.out.println("Erro ao tentar consultar por nome");
        }
    return lista;
    }
}
