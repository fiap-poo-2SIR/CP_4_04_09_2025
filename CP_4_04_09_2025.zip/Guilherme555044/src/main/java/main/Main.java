package main;
import Caloria.CaloriaDAO;
import Caloria.Caloria;

import java.util.List;


public class Main {
    public static void main(String[] args) {
        CaloriaDAO caloriaDAO = new CaloriaDAO();
        System.out.println("Inserindo dados dos alunos");
        caloriaDAO.inserir(new Caloria(1, "João", "corrida", 3, 500));
        caloriaDAO.inserir(new Caloria(2, "Ana", "Basquete", 2, 350));
        caloriaDAO.inserir(new Caloria(3, "Jorge", "boxe", 5, 1000));

        System.out.println("Listando alunos");
        List<Caloria> alunos = caloriaDAO.listarTodos();
        for (Caloria calorias : alunos) {
            System.out.println(calorias);
        }

        System.out.println("Gasto calórico total da atividade");
        double gastoCaloricoTotal = caloriaDAO.getGastoCaloricoTotal();
        System.out.println("Gasto calórico total: " + gastoCaloricoTotal);
    }
}
