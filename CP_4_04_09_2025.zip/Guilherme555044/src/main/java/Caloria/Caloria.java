package Caloria;

public class Caloria {
    private int id;
    private String aluno;
    private String atividade;
    private double duracao;
    private double caloria;

    public Caloria(int id, String aluno, String atividade, double duracao, double caloria) {
        this.id = id;
        this.aluno = aluno;
        this.atividade = atividade;
        this.duracao = duracao;
        this.caloria = caloria;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAluno() {
        return aluno;
    }

    public void setAluno(String aluno) {
        this.aluno = aluno;
    }

    public String getAtividade() {
        return atividade;
    }

    public void setAtividade(String atividade) {
        this.atividade = atividade;
    }

    public double getDuracao() {
        return duracao;
    }

    public void setDuracao(double duracao) {
        this.duracao = duracao;
    }

    public double getCaloria() {
        return caloria;
    }

    public void setCaloria(double caloria) {
        this.caloria = caloria;
    }
}
