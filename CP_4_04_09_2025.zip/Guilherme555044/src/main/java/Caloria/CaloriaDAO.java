package Caloria;

import main.Conexao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CaloriaDAO {
    public void inserir(Caloria caloria) {
        String sql = "INSERT INTO java_caloria (id, aluno, atividade, duracao, caloria) VALUES (?,?,?,?,?)";
        try (Connection conexao = Conexao.conectar();
             PreparedStatement ps = conexao.prepareStatement(sql)) {
            ps.setInt(1, caloria.getId());
            ps.setString(2, caloria.getAluno());
            ps.setString(3, caloria.getAtividade());
            ps.setDouble(4, caloria.getDuracao());
            ps.setDouble(5, caloria.getCaloria());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Erro ao inserir os dados do aluno: " + e.getMessage());
        }
    }
        public List<Caloria> listarTodos() {
            List<Caloria> calorias = new ArrayList<>();
            String sql = "SELECT id, aluno, atividade, duracao, caloria FROM java_caloria ORDER BY id";
            try (Connection conexao = Conexao.conectar();
                 Statement st = conexao.createStatement();
                 ResultSet rs = st.executeQuery(sql)){
                while (rs.next()) {
                    calorias.add(new Caloria(rs.getInt("id"), rs.getString("aluno"), rs.getString("atividade"), rs.getDouble("duracao"), rs.getDouble("caloria")));

                }
            } catch (SQLException e) {
                System.out.println("Erro ao listar os dados dos alunos: " + e.getMessage());
            }
            return calorias;
        }
        public double getGastoCaloricoTotal() {
            String sql = "SELECT id, aluno, atividade, duracao, caloria FROM java_caloria";
            double gastoCaloricoTotal = 0;
            try (Connection conexao = Conexao.conectar();
                 Statement st = conexao.createStatement();
                 ResultSet rs = st.executeQuery(sql)) {
                if (rs.next()) {
                    gastoCaloricoTotal = rs.getDouble(4) * rs.getDouble(5);
                }
            } catch (SQLException e) {
                System.out.println("Erro ao calcular o gasto calórico total: " + e.getMessage());
            }
            return gastoCaloricoTotal;
        }
    }

