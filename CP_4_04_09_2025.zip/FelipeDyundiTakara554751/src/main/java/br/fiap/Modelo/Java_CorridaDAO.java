package br.fiap.Modelo;

import br.fiap.conexao.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Java_CorridaDAO {
    private PreparedStatement ps;
    private String sql;
    private ResultSet rs;

    public void inserir (Java_Corrida javaCorrida){
        sql = "insert into corrida (id, motorista, distancia, consumo, preco) values (?, ?, ?, ?, ?)";
        try (Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            ps.setLong(1, javaCorrida.getId());
            ps.setString(2, javaCorrida.getMotorista());
            ps.setDouble(3, javaCorrida.getDistancia());
            ps.setDouble(4, javaCorrida.getConsumo());
            ps.setDouble(5, javaCorrida.getPreco());
            ps.execute();
        } catch (SQLException e){
            System.out.println("Erro ao inserir Corrida no banco de dados\n" + e.getMessage());
        }
    }
    public List<Java_Corrida> listar(){
        List<Java_Corrida> lista = new ArrayList<>();
        sql = "select id, motorista, distancia, consumo, preco from corrida";
        try (Connection connection = Conexao.conectar()){
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Java_Corrida javaCorrida = new Java_Corrida();

                javaCorrida.setId(rs.getLong("id"));
                javaCorrida.setMotorista(rs.getString("motorista"));
                javaCorrida.setDistancia(rs.getDouble("distancia"));
                javaCorrida.setConsumo(rs.getDouble("consumo"));
                javaCorrida.setPreco(rs.getDouble("preco"));

                lista.add(javaCorrida);
            }
        }catch (SQLException e){
            System.out.println("Erro ao listar corrida\n" + e.getMessage());
        }
        return lista;
    }
    public Double custo (Java_Corrida javaCorrida){
        double custo = 0.0;
        List <Java_Corrida>lista = listar();
        for(Java_Corrida javaCorrida1 : lista){
            custo = (javaCorrida1.getDistancia()/ javaCorrida1.getConsumo())* javaCorrida1.getPreco();
            System.out.println("Nome: "+ javaCorrida1.getMotorista() + "custo" + custo);
        }
        return null;
    }
    public void gastoTotal (Java_Corrida javaCorrida){
        List<Java_Corrida>lista = listar();
        double gastoTotal = 0.0;
        for (Java_Corrida javaCorrida1 :lista){
            String nome = javaCorrida.getMotorista();

        }
    }
}
