package br.fiap.conexao;

import br.fiap.Modelo.Java_Corrida;
import br.fiap.Modelo.Java_CorridaDAO;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        //inserir
        Java_CorridaDAO CDAO = new Java_CorridaDAO();
        Java_Corrida corr = new Java_Corrida();
        corr.setId(1L);
        corr.setMotorista("Felipe");
        corr.setDistancia(5.0);
        corr.setConsumo(2.5);
        corr.setPreco(6.0);
        CDAO.inserir(corr);
        //lista
        List<Java_Corrida> listaCorrida = CDAO.listar();
        if (listaCorrida.isEmpty()){
            System.out.println("Nenhuma corrida encontrada");
        } else {
            System.out.println("\n ===Lista De Corridas===");
            for (Java_Corrida Lcorrida : listaCorrida){
                System.out.println("id" + Lcorrida.getId() +
                                "motorista" + Lcorrida.getMotorista() +
                                "distancia" + Lcorrida.getDistancia() +
                                "consumo" + Lcorrida.getConsumo() +
                                "preco" + Lcorrida.getPreco());
            }
        }
        //Custo
        Double custo = CDAO.custo(corr);
        System.out.println("Nome: " + corr.getMotorista() + "Custo: " + custo);
    }
}
