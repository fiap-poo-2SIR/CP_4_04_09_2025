package br.fiap;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        //Inserir
        CaloriaDAO dao = new CaloriaDAO();

        Caloria v1 = new Caloria();
        v1.setId(1L);
        v1.setAluno("Patricia");
        v1.setAtividade("Corrida");
        v1.setDuracao(10.0);
        v1.setCaloria(10.0);
        dao.inserir(v1);

        Caloria v2 = new Caloria();
        v2.setId(2L);
        v2.setAluno("Selmini");
        v2.setAtividade("Bicicleta");
        v2.setDuracao(20.0);
        v2.setCaloria(20.0);
        dao.inserir(v2);

        Caloria v3 = new Caloria();
        v3.setId(3L);
        v3.setAluno("Mauro");
        v3.setAtividade("Futebol");
        v3.setDuracao(30.0);
        v3.setCaloria(30.0);
        dao.inserir(v3);

        //Listar
        List<Caloria>lista = dao.listar();
        for(Caloria v : lista){
            System.out.println(v.getId() + " | " + v.getAluno() + " | " + v.getAtividade() + " | " + v.getDuracao() + " | " + v.getCaloria());
        }
        System.out.println("\n");


        //Aluno e seu gasto
        System.out.println("O gasto calórico de " + v1.getAluno() + " na atividade, foi igual à: " + v1.getDuracao()*v1.getCaloria() + " Kcal");
        System.out.println("O gasto calórico de " + v2.getAluno() + " na atividade, foi igual à: " + v2.getDuracao()*v2.getCaloria() + " Kcal");
        System.out.println("O gasto calórico de " + v3.getAluno() + " na atividade, foi igual à: " + v3.getDuracao()*v3.getCaloria() + " Kcal");
        System.out.println("\n");


        //Total por aluno
        for(Caloria v : lista){
            if(v.getAluno().equals("Patricia")){
                System.out.println("O gasto calórico total de " + v.getAluno() + " foi igual à: " + (v.getCaloria()*v.getDuracao()) + " Kcal");
            }
            if (v.getAluno().equals("Selmini")){
                System.out.println("O gasto calórico total de " + v.getAluno() + " foi igual à: " + (v.getCaloria()*v.getDuracao()) + " Kcal");
            }
            if(v.getAluno().equals("Mauro")){
                System.out.println("O gasto calórico total de " + v.getAluno() + " foi igual à: " + (v.getCaloria()*v.getDuracao()) + " Kcal");
            }
        }
    }
}
