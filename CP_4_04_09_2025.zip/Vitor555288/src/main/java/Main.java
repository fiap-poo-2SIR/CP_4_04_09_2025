import java.util.List;

public class Main {
    public static void main(String[] args) {
        CorridaDAO dao = new CorridaDAO();
        Corrida corrida = new Corrida(1L,"Vitor",10, 5,20);
        dao.inserir(corrida);
        List<Corrida> lista = dao.listar();
            System.out.println("ID: " + corrida.getId() + " | Motorista: " + corrida.getMotorista() + " | Distancia: " + corrida.getDistancia() + " | Consumo: " + corrida.getConsumo() + " | Preco: " + corrida.getPreco());
    }
}
