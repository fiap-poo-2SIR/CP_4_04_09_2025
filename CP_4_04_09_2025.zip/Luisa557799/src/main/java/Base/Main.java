package Base;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        CorridaDAO dao=new CorridaDAO();
        Corrida corrida=new Corrida();
        corrida.setId(12345);
        corrida.setMotorista("Marcio");
        corrida.setDistancia(20.5);
        corrida.setConsumo(10);
        corrida.setPreco(200);


        //dao.inserir(corrida);

        List<Corrida> lista = dao.listar();
        for(Corrida c : lista){
            System.out.println(c.getId()+"\t"+c.getMotorista()+"\t"+c.getDistancia()+"\t"+c.getConsumo()+"\t"+c.getPreco());
            double custo;
                custo=corrida.getDistancia()/corrida.getConsumo();
                System.out.println("custo:"+custo);



        }










    }

}
