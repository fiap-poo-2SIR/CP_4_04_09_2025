package Base;

import Conexao.Conexao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CorridaDAO {
    PreparedStatement ps;
    ResultSet rs;
    String sql;

    public void inserir(Corrida corrida){
        sql="insert into java_corrida values(?,?,?,?,?)";
        try(Connection connection = Conexao.conectar()){
            ps=connection.prepareStatement(sql);
            ps.setLong(1,corrida.getId());
            ps.setString(2,corrida.getMotorista());
            ps.setDouble(3,corrida.getDistancia());
            ps.setDouble(4,corrida.getConsumo());
            ps.setDouble(5,corrida.getPreco());
            ps.execute();
        }
        catch(SQLException e){
            System.out.println("erro ao inserir dados na tabela java_corrida"+e);
        }
    }

    public List<Corrida> listar(){
        List<Corrida> lista=new ArrayList<>();
        sql="select * from java_corrida";
        try(Connection connection = Conexao.conectar()){
          ps=connection.prepareStatement(sql);
          rs=ps.executeQuery();
          while(rs.next()){
              Corrida corrida=new Corrida();
              corrida.setId(rs.getLong("id"));
              corrida.setMotorista(rs.getString("motorista"));
              corrida.setDistancia(rs.getDouble("distancia"));
              corrida.setConsumo(rs.getDouble("consumo"));
              corrida.setPreco(rs.getDouble("preco"));
              lista.add(corrida);
          }

        }catch(SQLException e){
            System.out.println("erro ao listar dados da tabela java_corrida");
        }
        return lista;
    }
}
