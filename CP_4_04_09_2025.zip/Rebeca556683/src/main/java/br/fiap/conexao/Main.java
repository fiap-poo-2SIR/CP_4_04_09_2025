package br.fiap.conexao;

import modelos.Corrida;
import modelos.corridaDAO;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println(Conexao.conectar());
        corridaDAO dao = new corridaDAO();
        // inserir
        Corrida corrida = new Corrida(3L,"motorista2",200.00,50.00,30.00);
        dao.inserir(corrida);

        //listar
        List<Corrida> lista = dao.listar();
        for (Corrida corrida1: lista){
            System.out.println(corrida.getId());
            System.out.println(corrida.getMotorista());
            System.out.println(corrida.getDistancia());
            System.out.println(corrida.getConsumo());
            System.out.println(corrida.getPreco());
            System.out.println("----------------------------------------");
        }
        //custo
        double custo = dao.custo();
        System.out.println("Nome do motorista: " + corrida.getMotorista() + " Custo da corrida: " + custo);

        System.out.println("-----------------------------------------------");

        double gasto = dao.gasto_total();
        System.out.println(" Nome do motorista " + corrida.getMotorista() + " Gasto total " + gasto);
    }
}
