package Models;

public class Caloria {
    private int id;
    private String aluno;
    private String atividade;
    private int duracao;
    private int caloria;
    private int gastoAtividade;
    private int gastoTotal;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAluno() {
        return aluno;
    }

    public void setAluno(String aluno) {
        this.aluno = aluno;
    }

    public String getAtividade() {
        return atividade;
    }

    public void setAtividade(String atividade) {
        this.atividade = atividade;
    }

    public int getDuracao() {
        return duracao;
    }

    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }

    public int getCaloria() {
        return caloria;
    }

    public void setCaloria(int caloria) {
        this.caloria = caloria;
    }

    public int getGastoAtividade() {
        return gastoAtividade;
    }

    public void setGastoAtividade(int gastoAtividade) {
        this.gastoAtividade = gastoAtividade;
    }

    public int getGastoTotal() {
        return gastoTotal;
    }

    public void setGastoTotal(int gastoTotal) {
        this.gastoTotal = gastoTotal;
    }

    @Override
    public String toString() {
        return String.format("Nome: %s | Atividade: %s | Duracao: %d | Caloria: %d", aluno, atividade, duracao, caloria);
    }
}
