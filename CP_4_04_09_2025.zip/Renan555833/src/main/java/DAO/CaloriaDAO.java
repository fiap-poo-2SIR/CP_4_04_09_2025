package DAO;

import Models.Caloria;
import Models.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CaloriaDAO {
    private PreparedStatement ps;
    private String sql;
    private ResultSet rs;


    public void insert(Caloria c) {
        sql = "INSERT INTO java_caloria VALUES (sequencia_caloria.nextval, ?, ?, ?, ?)";

        try (Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);

            ps.setString(1, c.getAluno());
            ps.setString(2, c.getAtividade());
            ps.setInt(3, c.getDuracao());
            ps.setInt(4, c.getCaloria());

            ps.execute();

        } catch (SQLException e) {
            System.out.println("Erro ao inserir no Banco de Dados" + e.getMessage());
        }
    }

    public List<Caloria> select() {
        List<Caloria> lista = new ArrayList<>();

        sql = "SELECT * FROM java_caloria";

        try (Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);

            rs = ps.executeQuery();

            while (rs.next()) {
                Caloria c = new Caloria();

                c.setId(rs.getInt("id"));
                c.setAluno(rs.getString("aluno"));
                c.setAtividade(rs.getString("atividade"));
                c.setDuracao(rs.getInt("duracao"));
                c.setCaloria(rs.getInt("caloria"));

                lista.add(c);
            }

        } catch (SQLException e) {
            System.out.println("Erro ao inserir no Banco de Dados" + e.getMessage());
        }

        return lista;
    }

    public List<Caloria> gastoAtividade() {
        List<Caloria> lista = new ArrayList<>();

        int gasto = 0;

        sql = "SELECT * FROM java_caloria";

        try (Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);

            rs = ps.executeQuery();

            while (rs.next()) {
                Caloria c = new Caloria();

                gasto = rs.getInt("duracao") * rs.getInt("caloria");

                c.setAluno(rs.getString("aluno"));
                c.setAtividade(rs.getString("atividade"));
                c.setGastoAtividade(gasto);

                lista.add(c);
            }

        } catch (SQLException e) {
            System.out.println("Erro ao inserir no Banco de Dados" + e.getMessage());
        }

        return lista;
    }

    public List<Caloria> gastoAluno(String nome) {
        List<Caloria> lista = new ArrayList<>();

        int gasto;

        int gastoTotal = 0;

        sql = "SELECT * FROM java_caloria WHERE aluno = ?";

        try (Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);

            ps.setString(1, nome);

            rs = ps.executeQuery();

            while (rs.next()) {
                Caloria c = new Caloria();

                c.setAluno(rs.getString("aluno"));

                gasto = rs.getInt("duracao") * rs.getInt("caloria");

                gastoTotal += gasto;

                c.setGastoTotal(gastoTotal);

                lista.add(c);
            }

        } catch (SQLException e) {
            System.out.println("Erro ao inserir no Banco de Dados" + e.getMessage());
        }

        return lista;
    }

}
