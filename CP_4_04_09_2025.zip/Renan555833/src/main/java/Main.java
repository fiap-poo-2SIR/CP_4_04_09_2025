import DAO.CaloriaDAO;
import Models.Caloria;

import java.util.List;

public class Main {

    public static void main(String[] args) {
        CaloriaDAO dao = new CaloriaDAO();

        Caloria aluno = new Caloria();

        aluno.setAluno("Teste");
        aluno.setAtividade("Bicicleta");
        aluno.setDuracao(1);
        aluno.setCaloria(2);

        dao.insert(aluno);

        List<Caloria> selectAll = dao.select();

        System.out.println("SELECT * FROM");

        for (Caloria c: selectAll) {

            System.out.println(c.toString());
        }

        System.out.println();

        List<Caloria> gastoTotal = dao.gastoAtividade();

        System.out.println("SELECT * FROM com gasto calórico total");
        for (Caloria c: gastoTotal) {
            System.out.println("Nome: " + c.getAluno() + " |Atividade: " + c.getAtividade() + " | Gasto total da atividade: " + c.getGastoAtividade());
        }

        System.out.println();

        List<Caloria> gastoTotalAluno = dao.gastoAluno("Renan");


        // Não consegui completar essa parte para trazer apenas um resultado :(

        System.out.println("SELECT * FROM com gasto calórico por aluno");
        for (Caloria c: gastoTotalAluno) {
            System.out.println("Nome: " + c.getAluno() + " | Gasto total do aluno: " + c.getGastoTotal());
        }
    }
}
