package main;

import DAO.CaloriaDAO;
import models.Caloria;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public class Main {
    public static void main(String[] args) {
        CaloriaDAO dao = new CaloriaDAO();

        // 1.
        /*
        dao.inserir(new Caloria(
                1,
                "aluno 1",
                "atividade1",
                5.5,
                2.2
        ));

        dao.inserir(new Caloria(
                2,
                "aluno 2",
                "atividade2",
                3.4,
                5.1
        ));

        dao.inserir(new Caloria(
                3,
                "aluno 1",
                "atividade2",
                6.2,
                9.1
        ));
        */

        // 2.
        /*
        List<Caloria> lista = dao.listar();
        lista.forEach(System.out::println);
        */

        // 3.
        /*
        List<Caloria> lista = dao.listar();
        lista.forEach(caloria -> System.out.println(caloria.getAluno() + ": " + (caloria.getDuracao() * caloria.getCaloria())));
        */

        // 4.
        /*
        List<Caloria> lista = dao.alunosIguais("aluno 1");
        System.out.println("Gasto total calórico do aluno: " + lista.get(1).getAluno());
        AtomicReference<Double> gastoTotal = new AtomicReference<>(0.0);
        lista.forEach(caloria -> gastoTotal.updateAndGet(v -> v + caloria.getCaloria() * caloria.getDuracao()));
        System.out.println(gastoTotal);
        */
    }
}
