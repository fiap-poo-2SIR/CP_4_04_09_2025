package DAO;

import main.Conexao;
import models.Caloria;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CaloriaDAO {
    private PreparedStatement ps;
    private ResultSet rs;
    private String sql;

    public void inserir (Caloria caloria) {
        sql = "INSERT INTO java_caloria VALUES(?, ?, ?, ?, ?)";

        try (Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);

            ps.setInt(1, caloria.getId());
            ps.setString(2, caloria.getAluno());
            ps.setString(3, caloria.getAtividade());
            ps.setDouble(4, caloria.getDuracao());
            ps.setDouble(5, caloria.getCaloria());

            ps.execute();
        } catch (SQLException e) {
            System.out.println("Erro ao inserir os dados, " + e.getMessage());;
        }
    }

    public List<Caloria> listar () {
        List<Caloria> lista = new ArrayList<>();

        sql = "select * from java_caloria";

        try (Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Caloria caloria = new Caloria(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getDouble(4),
                        rs.getDouble(5)
                );

                lista.add(caloria);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar os dados, " + e.getMessage());;
        }

        return lista;
    }

    public List<Caloria> alunosIguais (String nomeAluno) {
        List<Caloria> lista = new ArrayList<>();

        sql = "select * from java_caloria where aluno = ?";

        try (Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            ps.setString(1, nomeAluno);
            rs = ps.executeQuery();

            while (rs.next()) {
                Caloria caloria = new Caloria(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getDouble(4),
                        rs.getDouble(5)
                );

                lista.add(caloria);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar os dados, " + e.getMessage());;
        }

        return lista;
    }
}
