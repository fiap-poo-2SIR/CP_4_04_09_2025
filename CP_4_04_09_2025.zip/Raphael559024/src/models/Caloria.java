package models;

public class Caloria {
    private Integer id;
    private String aluno;
    private String atividade;
    private Double duracao;
    private Double caloria;

    public Caloria(Integer id, String aluno, String atividade, Double duracao, Double caloria) {
        this.id = id;
        this.aluno = aluno;
        this.atividade = atividade;
        this.duracao = duracao;
        this.caloria = caloria;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAluno() {
        return aluno;
    }

    public void setAluno(String aluno) {
        this.aluno = aluno;
    }

    public String getAtividade() {
        return atividade;
    }

    public void setAtividade(String atividade) {
        this.atividade = atividade;
    }

    public Double getDuracao() {
        return duracao;
    }

    public void setDuracao(Double duracao) {
        this.duracao = duracao;
    }

    public Double getCaloria() {
        return caloria;
    }

    public void setCaloria(Double caloria) {
        this.caloria = caloria;
    }

    @Override
    public String toString() {
        return "id = " + id +
                ", aluno = '" + aluno + '\'' +
                ", atividade = '" + atividade + '\'' +
                ", duracao = " + duracao +
                ", caloria = " + caloria;
    }
}
