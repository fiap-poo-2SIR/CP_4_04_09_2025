package br.fiap.entities;

public class Corrida {
    private int id;
    private String motorista;
    private Double distancia;
    private double consumo;
    private double preco;

    public Corrida(int id, String motorista, Double distancia, double consumo, double preco) {
        this.id = id;
        this.motorista = motorista;
        this.distancia = distancia;
        this.consumo = consumo;
        this.preco = preco;
    }
    public Corrida(){}

    @Override
    public String toString() {
        return String.format("ID = %d | Motorista = %s | Distância = %f | Consumo = R$%f | Preço = R$%f", id, motorista, distancia, consumo, preco);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMotorista() {
        return motorista;
    }

    public void setMotorista(String motorista) {
        this.motorista = motorista;
    }

    public Double getDistancia() {
        return distancia;
    }

    public void setDistancia(Double distancia) {
        this.distancia = distancia;
    }

    public double getConsumo() {
        return consumo;
    }

    public void setConsumo(double consumo) {
        this.consumo = consumo;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

}
