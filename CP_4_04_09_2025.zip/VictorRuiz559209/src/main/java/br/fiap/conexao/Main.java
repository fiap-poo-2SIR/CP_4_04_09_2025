package br.fiap.conexao;

import br.fiap.entities.Corrida;
import br.fiap.entities.CorridaDAO;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        CorridaDAO dao = new CorridaDAO();

        dao.inserir(new Corrida(1, "Antonio", 50.0, 100.0, 200.0));
        dao.inserir(new Corrida(2, "Antonio", 50.0, 100.0, 200.0));
        dao.inserir(new Corrida(3, "Pedro", 100.0, 200.0, 400.0));
        dao.inserir(new Corrida(4, "Carlos", 200.0, 300.0, 600.0));
        dao.inserir(new Corrida(5, "Lucas", 300.0, 400.0, 800.0));
        dao.inserir(new Corrida(6, "Marcelo", 400.0, 500.0, 1000.0));


        // listar tabela
        List<Corrida> lista = dao.listar();
        lista.forEach(System.out::println);

        System.out.println("\n--- MOTORISTA E CUSTO DA CORRIDA");

        // lista nome do motorista e custo de corrida
        for(Corrida c : lista){
            double custo = (c.getDistancia()/c.getConsumo())* c.getPreco();
            System.out.println("Motorista = " + c.getMotorista() + " | " + " Custo = R$" + custo);
        }


        int opc = 1;
        while(opc == 1){

            System.out.print("\nDeseja ver o gasto total de qual motorista = ");
            String motorista = sc.next();

            double gastoTotal = 0;
            for(Corrida c : lista){
                if(c.getMotorista().equalsIgnoreCase(motorista)){
                    gastoTotal += (c.getDistancia()/c.getConsumo())* c.getPreco();
                }
            }

            System.out.println("\nO Gasto total do motorista " + motorista + " é de = R$" + gastoTotal);

            System.out.println("\nDeseja ver o gasto de outro motorista \n1- SIM \n0- NÃO ");
            opc = sc.nextInt();

        }


    }
}
