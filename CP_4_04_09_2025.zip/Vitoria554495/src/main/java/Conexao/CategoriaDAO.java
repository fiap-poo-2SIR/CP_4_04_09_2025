package Conexao;

public class CategoriaDAO {
    CorridaDAO dao = new CorridaDAO();
    List<Corrida>list= dao.listar;
    for(Corrida categoria : lista){
        System.out.println(categoria.getId()+" --> "+categoria.getCategoria());
    }
}
