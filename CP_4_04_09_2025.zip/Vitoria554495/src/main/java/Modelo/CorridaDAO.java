package Modelo;

import Conexao.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CorridaDAO {
    private PreparedStatement ps;
    private ResultSet rs;
    private String sql;

public void inserir (Corrida corrida) throws SQLException {
    sql = "inserir into java_corrida values (seqd.nextal , ?,?,?,?,?)";
    try (Connection conection = Conexao.conectar()) {
        Connection conectar;
        ps = conectar.prepareStatement(sql);
        ps.setLong(1, corrida.getId());
        ps.setString(2, corrida.getMotorista());
        ps.setDouble(3, corrida.getDistancia());
        ps.setDouble(4, corrida.getConsumo());
        ps.setDouble(5, corrida.getPreco());
        ps.execute();
    } catch (SQLException e) {
        System.out.println("Erro ao inserir dados " + e);
    }
}
public List<Corrida> listar() throws SQLException {

    List<Corrida>lista = new ArrayList<>();
    sql = "select * from java_corrida";

    try(Connection connection = Conexao.conectar()){
        ps = connection.prepareStatement(sql);
        ps.executeQuery();

        while (rs.next()){
            Corrida corrida = new Corrida();

            corrida.setId(rs.getLong("id"));
            corrida.setMotorista(rs.getString("motorista"));
            corrida.setDistancia(rs.getDouble("distancia"));
            corrida.setConsumo(rs.getDouble("consumo"));
            corrida.setPreco(rs.getDouble("preço"));
            lista.add(corrida);
        }
        catch (SQLException e){
            System.out.println("Erro na tabela"+e);

        }
        return lista;
    }
    
    }
}