package br.com.fiap;

import br.com.fiap.entity.Corrida;
import br.com.fiap.entity.CorridaDao;
import br.com.fiap.entity.MotoristaCusto;

import java.util.ArrayList;
import java.util.List;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) {
        double gastoTotal = 0.0;
        List<MotoristaCusto> motoristaCustos = new ArrayList<>();
        Corrida corrida1 = new Corrida(4L,"Ricardo", 60.0, 15.0, 16.0);
        CorridaDao dao= new CorridaDao();
//        dao.inserirCorrida(corrida1);

        List<Corrida> corridas = dao.listarDados();
        corridas.forEach(System.out::println);
        System.out.println();
        for (Corrida c: corridas) {
            motoristaCustos = dao.exibirMoristaCusto(c);
            System.out.printf(motoristaCustos.toString() + "\n");
        }

        for (MotoristaCusto mc : motoristaCustos) {
            if (mc.getCusto() > gastoTotal) {
                gastoTotal = mc.getCusto();

            }
        }
        System.out.println("\n Gasto total: " + gastoTotal);
    }
}
