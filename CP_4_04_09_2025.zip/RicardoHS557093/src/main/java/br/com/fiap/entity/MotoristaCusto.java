package br.com.fiap.entity;

public class MotoristaCusto {

    private String morista;
    private Double custo;

    public MotoristaCusto(String morista, Double custo) {
        this.morista = morista;
        this.custo = custo;
    }

    public Double getCusto() {
        return custo;
    }

    public String getMorista() {
        return morista;
    }

    @Override
    public String toString() {
        return String.format(" Motorista: %s | Custo: %f ", getMorista(), getCusto());
    }
}
