package br.com.fiap.entity;

public class Corrida {

    private Long id;
    private String motorista;
    private double distancia;
    private double consumo;
    private double preco;

    public Corrida(Long id, String motorista, double distancia, double consumo, double preco) {
        this.id = id;
        this.motorista = motorista;
        this.distancia = distancia;
        this.consumo = consumo;
        this.preco = preco;
    }

    public Long getId() {
        return id;
    }

    public String getMotorista() {
        return motorista;
    }

    public double getDistancia() {
        return distancia;
    }

    public double getConsumo() {
        return consumo;
    }

    public double getPreco() {
        return preco;
    }

    @Override
    public String toString() {
        return " Corrida [" +
                " id = " + id +
                ", motorista = '" + motorista + '\'' +
                ", distancia = " + distancia +
                ", consumo = " + consumo +
                ", preco = " + preco + " ]";

    }
}
