package br.com.fiap.entity;

import br.com.fiap.conexao.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CorridaDao {
    PreparedStatement ps;
    ResultSet rs;
    String sql;

    public void inserirCorrida(Corrida corrida) {
        sql = "insert into java_corrida values(?,?,?,?,?)";
        try (Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            ps.setLong(1, corrida.getId());
            ps.setString(2, corrida.getMotorista());
            ps.setDouble(3, corrida.getDistancia());
            ps.setDouble(4, corrida.getConsumo());
            ps.setDouble(5, corrida.getPreco());
            ps.execute();
            System.out.printf("Inserção realizada com sucesso!\n");
        } catch (SQLException e) {
            System.out.printf("Não foi possivel inserir dados ao banco: " + e.getMessage());
        }
    }

    public List<Corrida> listarDados() {
        List<Corrida> lista = new ArrayList<>();
        sql = "select * from java_corrida";

        try (Connection connection = Conexao.conectar()) {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new Corrida(rs.getLong("id"),
                        rs.getString("motorista"),
                        rs.getDouble("distancia"),
                        rs.getDouble("consumo"),
                        rs.getDouble("preco")
                ));
            }
            ps.execute();
            System.out.printf("Listagem realizadacom sucesso!\n");
        } catch (SQLException e) {
            System.out.printf("Não foi possivel listar os dados da tabela java_corrida: " + e.getMessage());
        }

        return lista;
    }

    public List<MotoristaCusto> exibirMoristaCusto(Corrida corridas) {
        List<MotoristaCusto> motoristaCustos = new ArrayList<>();
        Double mult = corridas.getDistancia() / corridas.getConsumo();
        Double custo = corridas.getPreco() * mult;
        String nome = corridas.getMotorista();
        MotoristaCusto mc = new MotoristaCusto(nome, custo);
        motoristaCustos.add(mc);
        return motoristaCustos;
    }


}
